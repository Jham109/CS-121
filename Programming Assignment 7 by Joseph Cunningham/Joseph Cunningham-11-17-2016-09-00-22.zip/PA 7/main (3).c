#include "math.h"

int main(void)
{
	int option = 0, difficult = 1, score = 0;
	char initials[4] = "";
	FILE *infile = NULL;
	
	infile = fopen("score.txt", "w");

	srand((unsigned int)time(NULL));

	do {
		option = main_menu();
		//menu_selection(option, initials, &difficult, &score);
		switch (option)
		{
		case LEARN:
			learning();
			break;
		case INITIALS:
			puts("Enter your initials (3 characters): ");
			scanf("%s", initials);
			system("cls");
			break;
		case DIFFICULTY:
			do {
				printf("Enter a difficulty(1 - 5): ");
				scanf("%d", difficult);
				system("cls");
			} while (difficult < 1 && difficult > 5);
			break;
		case START:
			generate_problem(difficult, initials, &score);
			break;
		case QUIT:
			printf("Thank you!");
			break;
		default:
			break;
		}
	} while (option != QUIT);

	fprintf(infile, "%s Score: %d", initials, score);
	fclose(infile);
	return 0;
}