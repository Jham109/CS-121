#include "math.h"

int main_menu(void)
{
	int option = 0;

	
	do{
		printf("Welcome\n");
		printf("1. Learn how to use the program\n");
		printf("2. Enter your initials(3 characters)\n");
		printf("3. Difficulty selection\n");
		printf("4. Start a new sequence of problems\n");
		printf("5. Save and quit\n");
		scanf("%d", &option);
		system("cls");
	}while (option < 1 || option > 5);
	
	return option;
}

void menu_selection(int option, char initials[], int *difficult, int *score)
{
	switch (option)
	{
	case LEARN:
		learning();
		break;
	case INITIALS:
		puts("Enter your initials (3 characters): ");
		scanf("%s", initials);
		system("cls");
		break;
	case DIFFICULTY:
		do {
			printf("Enter a difficulty(1 - 5): ");
			scanf("%d", difficult);
			system("cls");
		} while (difficult < 1 && difficult > 5);
		break;
	case START:
		generate_problem(*difficult, initials, *score);
		break;
	case QUIT:
		printf("Thank you!");
		break;
	default:
		break;
	}
}

void generate_problem(int difficult, char initials[], int *score)
{
	int answer = 0, right_wrong = 0, question = 1;
	char y_n = '\0';

	do {
		printf("[%s] [Difficulty %d: Question %d out of 10] \t [SCORE : %d]\n\n", initials, difficult, question, *score);
		printf("Evalute the following a equation: \n");

		if (difficult == 1)
		{
			answer = easy_problem(question);	
			question++;
		}
		else if (difficult == 2)
		{
			answer = fair_problem(question);			
			question++;
		}
		else if (difficult == 3)
		{
			answer = intermediate_problem(question);		
			question++;
		}
		else if (difficult == 4)
		{
			answer = hard_problem(question);	
			question++;
		}
		else if (difficult == 5)
		{
			answer = impossible_problem(question);
			question++;
		}
		*score += answer * difficult;
		system("pause");
		system("cls");
		
	} while (question <= 10);
	
}

int easy_problem(int harder)
{
	int num1 = 0, num2 = 0, num3 = 0, sum = 0, difference = 0, answer = 0, right_wrong = 0;
	char op1 = '\0', op2 = '\0';

	num1 = rand() % (harder * harder) + 1;
	num2 = rand() % (harder * harder) + 1;
	num3 = rand() % (harder * harder) + 1;
	op1 = generate_easy_operater();
	op2 = generate_easy_operater();
	printf("%d %c %d %c %d =\n", num1, op1, num2, op2, num3);

	if (op1 == '+')
	{
		sum = num1 + num2;
		if (op2 == '+')
		{
			answer = sum + num3;
		}
		else // the second operater is '-'
		{
			answer = sum - num3;
		}
	}
	else // the first operater is '-'
	{
		difference = num1 - num2;
		
		if (op2 == '+')
		{
			answer = difference + num3;
		}
		else
		{
			answer = difference - num3;
		}		
	}
	right_wrong = check_answer(answer);
	return right_wrong;
}

int fair_problem(int harder)
{
	int num1 = 0, num2 = 0, answer = 0, right_wrong = 0;

	num1 = rand() % (harder * harder) + 1;
	num2 = rand() % (harder * harder) + 1;
	printf("%d * %d =\n", num1, num2);
	
	answer = num1 * num2;
	right_wrong = check_answer(answer);
	return right_wrong;
}

int intermediate_problem(int harder)
{
	int num1 = 0, num2 = 0, right_wrong = 0, remainder = 0, quotient = 0;
	
	num1 = rand() % (harder * harder) + 1;
	num2 = rand() % (harder * harder) + 1;
	printf("%d / %d =\n", num1, num2);
	
	remainder = num1 % num2;
	quotient = num1 / num2;
	right_wrong = check_division_answer(remainder, quotient);

	return right_wrong;
	
}

int hard_problem(int harder)
{
	int num1 = 0, num2 = 0, num3 = 0, right_wrong = 0, answer = 0;
	int quotient = 0, product = 0;
	char op1 = '\0', op2 = '\0';
	num1 = positive_negative(harder);
	num2 = positive_negative(harder);
	num3 = positive_negative(harder);
	op1 = generate_hard_operater();
	op2 = generate_hard_operater();

	printf("%d %c %d %c %d =\n", num1, op1, num2, op2, num3);

	if (op1 == '+')	
	{
		if (op2 == '+')
		{
			answer = num1 + num2 + num3;
		}
		else if(op2 == '-')
		{
			answer = num1 + num2 - num3;
		}
		else if (op2 == '*')
		{
			answer = num1 + num2 * num3;
		}
		else if (op2 == '/')
		{
			answer = num1 + num2 / num3;
		}
	}
	else if (op1 == '-')
	{
		if (op2 == '+')
		{
			answer = num1 - num2 + num3;
		}
		else if (op2 == '-')
		{
			answer = num1 - num2 - num3;
		}
		else if (op2 == '*')
		{
			answer = num1 - num2 * num3;
		}
		else if (op2 == '/')
		{
			answer = num1 - num2 / num3;
		}
	}
	else if (op1 == '*')
	{
		product = num1 * num2;
		if (op2 == '+')
		{
			answer = product + num3;
		}
		else if (op2 == '-')
		{
			answer = product - num3;
		}
		else if (op2 == '*')
		{
			answer = product * num3;
		}
		else if (op2 == '/')
		{
			answer = product / num3;
		}
	}
	else if (op1 == '/')
	{
		quotient = num1 / num2;
		if (op2 == '+')
		{
			answer = quotient + num3;
		}
		else if (op2 == '-')
		{
			answer = quotient - num3;
		}
		else if (op2 == '*')
		{
			answer = quotient * num3;
		}
		else if (op2 == '/')
		{
			answer = quotient / num3;
		}
	}
	right_wrong = check_answer(answer);
	return right_wrong;
	
}

int impossible_problem(int harder)
{
	int num1 = 0, num2 = 0, num3 = 0, num4 = 0, right_wrong = 0, answer = 0;
	int quotient = 0, product = 0;
	char op1 = '\0', op2 = '\0', op3 = '\0';
	num1 = pos_neg_impossible(harder); 
	num2 = pos_neg_impossible(harder); 
	num3 = pos_neg_impossible(harder);
	num4 = pos_neg_impossible(harder);
	op1 = generate_hard_operater();
	op2 = generate_hard_operater();
	op3 = generate_hard_operater();

	printf("%d %c %d %c %d %c %d =\n", num1, op1, num2, op2, num3, op3, num4);

	if (op1 == '+')
	{
		if (op2 == '+')
		{
			if (op3 == '+')
			{
				answer = num1 + num2 + num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 + num2 + num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 + num2 + num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 + num2 + num3 / num4;
			}
		}
		else if (op2 == '-')
		{
			if (op3 == '+')
			{
				answer = num1 + num2 - num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 + num2 - num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 + num2 - num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 + num2 - num3 / num4;
			}
		}
		else if (op2 == '*')
		{
			if (op3 == '+')
			{
				answer = num1 + num2 * num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 + num2 * num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 + num2 * num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 + num2 * num3 / num4;
			}
		}
		else if (op2 == '/')
		{
			if (op3 == '+')
			{
				answer = num1 + num2 / num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 + num2 / num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 + num2 / num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 + num2 / num3 / num4;
			}
		}
	}
	else if (op1 == '-') // first operator is subtraction
	{
		if (op2 == '+')
		{
			if (op3 == '+')
			{
				answer = num1 - num2 + num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 - num2 + num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 - num2 + num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 - num2 + num3 / num4;
			}
		}
		else if (op2 == '-')
		{
			if (op3 == '+')
			{
				answer = num1 - num2 - num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 - num2 - num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 - num2 - num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 - num2 - num3 / num4;
			}
		}
		else if (op2 == '*')
		{
			if (op3 == '+')
			{
				answer = num1 - num2 * num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 - num2 * num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 - num2 * num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 - num2 * num3 / num4;
			}
		}
		else if (op2 == '/')
		{
			if (op3 == '+')
			{
				answer = num1 - num2 / num3 + num4;
			}
			else if (op3 == '-')
			{
				answer = num1 - num2 / num3 - num4;
			}
			else if (op3 == '*')
			{
				answer = num1 - num2 / num3 * num4;
			}
			else if (op3 == '/')
			{
				answer = num1 - num2 / num3 / num4;
			}
		}
	}
	else if (op1 == '*') // if the first operator is multiplication
	{
		product = num1 * num2;
		if (op2 == '+')
		{
			if (op3 == '+')
			{
				answer = product + num3 + num4;
			}
			if (op3 == '-')
			{
				answer = product + num3 - num4;
			}
			if (op3 == '*')
			{
				answer = product + num3 * num4;
			}
			if (op3 == '/')
			{
				answer = product + num3 / num4;
			}
		}
		else if (op2 == '-')
		{
			if (op3 == '+')
			{
				answer = product - num3 + num4;
			}
			if (op3 == '-')
			{
				answer = product - num3 - num4;
			}
			if (op3 == '*')
			{
				answer = product - num3 * num4;
			}
			if (op3 == '/')
			{
				answer = product - num3 / num4;
			}
		}
		else if (op2 == '*')
		{
			if (op3 == '+')
			{
				answer = product * num3 + num4;
			}
			if (op3 == '-')
			{
				answer = product * num3 - num4;
			}
			if (op3 == '*')
			{
				answer = product * num3 * num4;
			}
			if (op3 == '/')
			{
				answer = product * num3 / num4;
			}
		}
		else if (op2 == '/')
		{
			if (op3 == '+')
			{
				answer = product / num3 + num4;
			}
			if (op3 == '-')
			{
				answer = product / num3 - num4;
			}
			if (op3 == '*')
			{
				answer = product / num3 * num4;
			}
			if (op3 == '/')
			{
				answer = product / num3 / num4;
			}
		}
	}
	else if (op1 == '/') // first operator is division
	{
		quotient = num1 / num2;
		if (op2 == '+')
		{
			if (op3 == '+')
			{
				answer = quotient + num3 + num4;
			}
			if (op3 == '-')
			{
				answer = quotient + num3 - num4;
			}
			if (op3 == '*')
			{
				answer = quotient + num3 * num4;
			}
			if (op3 == '/')
			{
				answer = quotient + num3 / num4;
			}
		}
		else if (op2 == '-')
		{
			if (op3 == '+')
			{
				answer = quotient - num3 + num4;
			}
			if (op3 == '-')
			{
				answer = quotient - num3 - num4;
			}
			if (op3 == '*')
			{
				answer = quotient - num3 * num4;
			}
			if (op3 == '/')
			{
				answer = quotient - num3 / num4;
			}
		}
		else if (op2 == '*')
		{
			if (op3 == '+')
			{
				answer = quotient * num3 + num4;
			}
			if (op3 == '-')
			{
				answer = quotient * num3 - num4;
			}
			if (op3 == '*')
			{
				answer = quotient * num3 * num4;
			}
			if (op3 == '/')
			{
				answer = quotient * num3 / num4;
			}
		}
		else if (op2 == '/')
		{
			if (op3 == '+')
			{
				answer = quotient / num3 + num4;
			}
			if (op3 == '-')
			{
				answer = quotient / num3 - num4;
			}
			if (op3 == '*')
			{
				answer = quotient / num3 * num4;
			}
			if (op3 == '/')
			{
				answer = quotient / num3 / num4;
			}
		}
	}
	right_wrong = check_answer(answer);
	return right_wrong;
}

char generate_hard_operater(void)
{
	char operater = '\0';
	int ops = 0;

	ops = rand() % 4; // '+' = 1 and '-' = 0 and '*' = 2 and '/' = 3

	if (ops == 1)
	{
		operater = '+';
	}
	else if (ops == 2)
	{
		operater = '*';
	}
	else if (ops == 3)
	{
		operater = '/';
	}
	else 
	{
		operater = '-';
	}

	return operater;
}

char generate_easy_operater(void)
{
	char operater = '\0';
	int plus_minus = 0;

	plus_minus = rand() % 2; // '+' = 1 and '-' = 0
	
	if (plus_minus)
	{
		operater = '+';
	}
	else
	{
		operater = '-';
	}

	return operater;
}

int positive_negative(int harder)
{
	int number = 0, pos_neg = 0;
	
	pos_neg = rand() % 2;

	if (pos_neg) // if its 1 then its positive
	{
		number = rand() % (harder * harder) + 1;
	}
	else // its negative
	{
		number = -(rand() % (harder * harder) + 1);
	}
	return number;
}

int pos_neg_impossible(int harder)
{
	int number = 0, pos_neg = 0;

	pos_neg = rand() % 2;

	if (pos_neg) // if its 1 then its positive
	{
		number = (rand() % (harder* 100) + 1);
	}
	else // its negative
	{
		number = -(rand() % (harder * 100) + 1);
	}
	return number;
}

int check_answer(int answer)
{
	int correct = 0, input = 0;

	scanf("%d", &input);

	if (input == answer)
	{
		correct = 1;
		printf("That's correct!!\n");
	}
	else
	{
		printf("That's incorrect\n");
	}

	return correct;
}
int check_division_answer(int remainder, int quotient)
{
	int correct = 0, input_q = 0, input_r = 0;
	char r = '\0';
	scanf("%d %c %d", &input_q, &r, &input_r);
	if (r == 'R' || r == 'r')
	{
		if (input_q == quotient)
		{
			if (input_r == remainder)
			{
				correct = 1;
				printf("That's correct!!\n");
			}
			else
			{
				printf("That's incorrect\n");
			}
		}
		else
		{
			printf("That's incorrect\n");
		}
	}
	else
	{
		printf("Enter the correct letter to represent the remainder please");
	}

	return correct;
}

void learning(void)
{
	printf("First select Enter your initials then select a difficulty before you start the program or else it starts at the easiest level\n");
	printf("Difficulties:\n");
	printf("1 - Easy: Includes addition and subtraction problems \n");
	printf("2 - Fair: Includes multiplication problems, with positive single digit operands and up to two terms only \n");
	printf("3 - Intermediate: Includes division problems, with positive single digit operands and up to two terms only \n");
	printf("4 - Hard: Includes a mix of addition, subtraction, multiplication, and division problems, with positive and negative single digit operands \n");
	printf("5 - Impossible: Includes a mix of addition, subtraction, multiplication, and division problems, with positive and negative  \n");
}