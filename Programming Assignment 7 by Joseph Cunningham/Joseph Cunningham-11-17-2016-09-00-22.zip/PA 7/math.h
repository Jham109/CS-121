#ifndef MATH_H
#define MATH_H

#define LEARN 1
#define INITIALS 2
#define DIFFICULTY 3
#define START 4
#define QUIT 5

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

int main_menu(void);
void menu_selection(int option, char initials[], int *difficult, int *score);
void learning(void);
void generate_problem(int difficult, char initials [], int *score);
int easy_problem(int harder);
int fair_problem(int harder);
int intermediate_problem(int harder);
int hard_problem(int harder);
int impossible_problem(int harder);
char generate_easy_operater(void);
char generate_hard_operater(void);
int positive_negative(int harder);
int pos_neg_impossible(int harder); // generates double and tripple digit negative or positive numbers
int check_answer(int answer);
int check_division_answer(int remainder, int quotient);
#endif // !MATH_H