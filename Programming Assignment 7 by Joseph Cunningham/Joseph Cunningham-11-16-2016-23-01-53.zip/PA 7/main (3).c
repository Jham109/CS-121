#include "math.h"

int main(void)
{
	int option = 0, difficult = 1, score = 0;
	char initials[4] = "";
	FILE *infile = NULL;
	
	infile = fopen("score.txt", "w");

	srand((unsigned int)time(NULL));

	do {
		option = main_menu();
		menu_selection(option, initials, &difficult, &score);
	} while (option != QUIT);

	fprintf(infile, "%s Score: %d", initials, score);
	fclose(infile);
	return 0;
}