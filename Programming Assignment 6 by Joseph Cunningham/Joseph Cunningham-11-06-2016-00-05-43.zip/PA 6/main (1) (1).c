#include "Battleship (1).h"

int main(void)
{
	char p1_board[10][10] = { { '\0', '~' },{ '~' } }, p2_board[10][10] = { '\0' };
	int hit = 0, current_player = 0, winner = 0, shot_row = 0, shot_col = 0;
	FILE *infile = NULL;
	Stats p1_stats = { 0, 0, 0, 0.0 };
	Stats p2_stats = { 0, 0, 0, 0.0 };

	infile = fopen("battleship.log", "w");
	srand((unsigned int)time(NULL));

	welcome_screen();
	init_board(p1_board, 10, 10); // set each cell in the 2-D array to the water '~' symbol
	init_board(p2_board, 10, 10);
	randomly_place_ships(p2_board, 5, 'c'); // places carrier
	randomly_place_ships(p2_board, 4, 'b'); // places battleship
	randomly_place_ships(p2_board, 3, 'r'); // places cruiser
	randomly_place_ships(p2_board, 3, 's'); // places submarine
	randomly_place_ships(p2_board, 2, 'd'); // places destroyer
	manually_place_ships(p1_board, 10, 10);
	system("pause");
	system("cls");
	current_player = who_starts_first();

	while (winner == 0)
	{
		putchar('\n');
		print_board(p1_board, 10, 10, 1);
		putchar('\n');
		print_board(p2_board, 10, 10, 2);

		if (current_player == 1)
		{
			hit = check_shot(p2_board, 1, &shot_row, &shot_col, infile);
			update_board(p2_board, hit, shot_row, shot_col, infile);
			is_sunk(p2_board, infile, 2);
			update_stats(&p1_stats, hit);
			if (!hit) // if player doesnt hit then switch players
			{
				current_player += 1;
			}
		}
		else //player 2
		{
			hit = check_shot(p1_board, 2, &shot_row, &shot_col, infile);
			update_board(p1_board, hit, shot_row, shot_col, infile);
			is_sunk(p1_board, infile, 1);
			update_stats(&p2_stats, hit);
			if (!hit)
			{
				current_player -= 1;
			}
		}
		winner = is_winner(p1_stats, p2_stats);
		system("pause");
		system("cls");
	}
	printf("Player %d is the winner!!\n", winner);
	p1_stats.hit_miss_ratio = p1_stats.num_hits / p1_stats.num_misses;
	p2_stats.hit_miss_ratio = p2_stats.num_hits / p2_stats.num_misses;
	print_stats(infile, p1_stats, p2_stats);
	fclose(infile);
}