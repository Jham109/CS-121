#ifndef BATTLESHIP_H
#define BATTLESHIP_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define ROWS 10
#define COLS 10

void welcome_screen(void);
int who_starts_first(void);
void init_board(char board[][10], int rows, int cols);
void print_board(char board[][10], int rows, int cols, int player);
void manually_place_ships(char board[][10], int rows, int cols);
void each_ship(char board[][10], int spaces, char ship, char string[]);
void randomly_place_ships(char board[][10], int spaces, char ship);
int check_shot(char board[][10], int player, int *shot_row, int *shot_col, FILE *infile);

typedef enum direction
{
	HOR, VER
} Dir;

typedef struct stats
{
	int num_hits;
	int num_misses;
	int num_shots;
	double hit_miss_ratio;
}Stats;

void update_stats(Stats *p1_stats_ptr, int hit);
void update_board(char board[][10], int hit, int shot_row, int shot_col);
int is_winner(Stats p1_stats, Stats p2_stats);
void print_stats(FILE *infile, Stats p1_stats, Stats p2_stats);

void generate_strt_pt(int *row_ptr, int *col_ptr, Dir direction, int length);
void generate_shot(int *row_ptr, int *col_ptr);
void is_sunk(char board[][10], FILE *infile, int player);

#endif // !BATTLESHIP_H