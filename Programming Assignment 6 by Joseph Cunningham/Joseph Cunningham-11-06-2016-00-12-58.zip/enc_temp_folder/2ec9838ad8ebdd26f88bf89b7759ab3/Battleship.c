#include "Battleship (1).h"


void welcome_screen(void)
{
	printf("*****WELCOME TO BATTLESHIP*****\n\n");
	printf("The rules are simple...just guess where the enemies ships are before they find yours!!!\n");
	printf("1. Place your ships\n");
	printf("2. Enter coordinates to fire a shot at your enemy, if you hit you can fire again\n");
	printf("3. The 1st player to sink all of their enemies ships wins\n");
	system("pause");
	system("cls");
}

int who_starts_first(void)
{
	int player = 0;

	player = rand() % 2 + 1;

	printf("Player %d has been randomly selcted to go first\n", player);

	return player;
}

void init_board(char board[][10], int rows, int cols)
{
	int row_index = 0, col_index = 0;

	for (row_index = 0; row_index < rows; ++row_index) // controls which row
	{
		for (col_index = 0; col_index < cols; ++col_index) // controls which column
		{
			board[row_index][col_index] = '~';
		}
	}
}

void print_board(char board[][10], int rows, int cols, int player)
{
	int row_index = 0, col_index = 0;

	printf("Player %d\n", player);

	printf("  ");
	for (int index = 0; index < cols; index++) // prints header for the columns
	{
		printf("%d ", index);
	}
	putchar('\n');

	for (row_index = 0; row_index < rows; ++row_index) // controls which row
	{
		printf("%d ", row_index); // prints header for the rows

		for (col_index = 0; col_index < cols; ++col_index) // controls which column
		{
			if (player == 2)
			{
				if (board[row_index][col_index] != '*' || board[row_index][col_index] != '~') // hides player 2's ships
				{
					printf("~ ");
				}
				else // if player 2's ship got hit
				{
					printf("%c ", board[row_index][col_index]);
				}
			}
			else // player 1
			{
				printf("%c ", board[row_index][col_index]);
			}
		}
		putchar('\n');
	}
}

void manually_place_ships(char board[][10], int rows, int cols)
{
	
	printf("Your board: ");
	print_board(board, 10, 10, 1);
	
	//system("pause");
	//system("cls");
	each_ship(board, 5, 'c', "Carrier");
	print_board(board, 10, 10, 1);
	each_ship(board, 4, 'b', "Battleship");	
	print_board(board, 10, 10, 1);
	each_ship(board, 3, 'r', "Cruiser");
	print_board(board, 10, 10, 1);
	each_ship(board, 3, 's', "Submarine");
	print_board(board, 10, 10, 1);
	each_ship(board, 2, 'd', "Destroyer");
	print_board(board, 10, 10, 1);
	system("pause");
}

void each_ship(char board[][10], int spaces, char ship, char string[])
{
	int row = 0, col = 0;
	char h_v = '\0';
	printf("Place the starting point of your %s(%d spaces): ", string, spaces);
	scanf("%d%d", &row, &col);
	printf("Would you like to place it horizontally or vertically?\n Horizontal ships will be placed from left to right and Vertical ships from top to bottom (V/H): ");
	scanf(" %c", &h_v);

	if (h_v == 'V' || h_v == 'v') // Vertically
	{
		if (row < 0 || row > (10 - spaces))
		{
			printf("Your ship wont fit there please re-enter starting points\n");
			each_ship(board, spaces, ship, string);
		}
		else 
		{
			for (int index = 0; index < spaces; index++)
			{
				board[row + index][col] = ship;
			}
		}
	}
	else // user chose horizontally
	{
		if (col < 0 || col > (10 - spaces))
		{
			printf("Your ship wont fit there please re-enter starting points\n");
			each_ship(board, spaces, ship, string);
		}
		else
		{
			for (int index = 0; index < spaces; index++)
			{
				board[row][col + index] = ship;
			}
		}
	}
	system("cls");
}

Dir generate_dir(void)
{
	Dir direction = HOR;

	direction = (Dir)(rand() % 2);

	return direction;
}

void generate_strt_pt(int *row_ptr, int *col_ptr, Dir direction, int length)
{
	if (direction == HOR) // horizontal
	{
		*row_ptr = rand() % ROWS;
		*col_ptr = rand() % (COLS - length + 1);
	}
	else // vertical
	{
		*row_ptr = rand() % (ROWS - length + 1);
		*col_ptr = rand() % COLS;
	}
}

void randomly_place_ships(char board[][10], int spaces, char ship)
{
	int strt_row = 0, strt_col = 0, water = 0;

	Dir direction = generate_dir();
	generate_strt_pt(&strt_row, &strt_col, direction, 5);

	if (direction == HOR) //horizontally
	{
		for (int index = 0; index < spaces; index++)
		{
			if (board[strt_row][strt_col + index] == '~') //checks to see if a ship is already there
			{
				water++;								
			}			
		}
		
		if (water == spaces)
		{
			for (int index = 0; index < spaces; index++)
			{
				board[strt_row][strt_col + index] = ship;
			}
		}
		else
		{
			randomly_place_ships(board, spaces, ship);
		}
		
	}
	else //vertically
	{
		for (int index = 0; index < spaces; index++)
		{
			if (board[strt_row + index][strt_col] == '~')
			{
				water++;
			}
		}
		if (water == spaces)
		{
			for (int index = 0; index < spaces; index++)
			{
				board[strt_row + index][strt_col] = ship;
			}
		}
		else
		{
			randomly_place_ships(board, spaces, ship);
		}
	}	
}

int check_shot(char board[][10], int player, int *shot_row, int *shot_col, FILE *infile)
{
	int row = 0, col = 0, hit_or_miss = 0;

	if (player == 1)
	{
		printf("Enter coordinates to fire: ");
		scanf("%d%d", &row, &col);
	}
	else
	{
		generate_shot(&row, &col);
	}
	*shot_row = row;
	*shot_col = col;
	if (board[row][col] == '*' || board[row][col] == 'm')
	{
		if (player == 1)
		{
			printf("You've already fired there, select new coordinates\n");
			system("pause");
		}
		check_shot(board, player, *shot_row, *shot_col, infile);

	}
	if (board[row][col] != '~')
	{
		printf("Player %d's shot was a hit!!!\n", player);
		fprintf(infile, "Player %d's shot on (%d,%d) was a hit", player, row, col);
		hit_or_miss = 1;
	}
	else
	{
		printf("Player %d missed their shot\n", player);
		fprintf(infile, "Player %d's shot on (%d,%d) was a miss", player, row, col);
	}
	return hit_or_miss;
}

void update_stats(Stats *p1_stats_ptr, int hit)
{
	if (hit)
	{
		p1_stats_ptr->num_hits += 1;
	}
	else
	{
		p1_stats_ptr->num_misses += 1;
	}

	p1_stats_ptr->num_shots += 1;
}

void update_board(char board[][10], int hit, int shot_row, int shot_col)
{
	if (hit)
	{
		board[shot_row][shot_col] = '*';
	}
	else
	{
		board[shot_row][shot_col] = 'm';
	}
}

int is_winner(Stats p1_stats, Stats p2_stats)
{
	int winner = 0, p1_hits = 0, p2_hits = 0;

	if (p1_stats.num_hits == 17) // The max number of hits a player can get is 17 
	{
		winner = 1;
	}
	if (p2_stats.num_hits == 17)
	{
		winner = 2;
	}
	return winner;
}

void print_stats(FILE *infile, Stats p1_stats, Stats p2_stats)
{
	fprintf(infile, "Player 1's stats\n ");
	fprintf(infile, "Number of hits: %d\n", p1_stats.num_hits);
	fprintf(infile, "Number of misses: %d\n", p1_stats.num_misses);
	fprintf(infile, "Number of shots: %d\n", p1_stats.num_shots);
	fprintf(infile, "Hit and miss ratio: %d\n", p1_stats.hit_miss_ratio);
	fprintf(infile, "Player 2's stats\n ");
	fprintf(infile, "Number of hits: %d\n", p2_stats.num_hits);
	fprintf(infile, "Number of misses: %d\n", p2_stats.num_misses);
	fprintf(infile, "Number of shots: %d\n", p2_stats.num_shots);
	fprintf(infile, "Hit and miss ratio: %d\n", p2_stats.hit_miss_ratio);
}

void generate_shot(int *row_ptr, int *col_ptr)
{
	*row_ptr = rand() % 10;
	*col_ptr = rand() % 10;
}

void is_sunk(char board[][10], FILE *infile, int player)
{
	char cell = '\0';
	int carrier = 0, cruiser = 0, battleship = 0, destroyer = 0, submarine = 0;

	for (int index = 0; index < 10; index++)
	{
		for (int index2 = 0; index2 < 10; index2++)
		{
			cell = board[index][index2];

			if (cell == 'c')
			{
				carrier += 1;
			}
			else if (cell == 'b')
			{
				battleship += 1;
			}
			else if (cell == 'r')
			{
				carrier += 1;
			}
			else if (cell == 's')
			{
				submarine += 1;
			}
			else if (cell == 'd')
			{
				destroyer += 1;
			}
		}
	}
	if (carrier == 0)
	{
		printf("Player %d's Carrier was sunk!!\n", player);
		fprintf(infile, "Player %d's Carrier was sunk!!\n", player);
	}
	if (cruiser == 0)
	{
		printf("Player %d's Cruiser was sunk!!\n", player);
		fprintf(infile, "Player %d's Cruiser was sunk!!\n", player);
	}
	if (battleship == 0)
	{
		printf("Player %d's Battleship was sunk!!\n", player);
		fprintf(infile, "Player %d's Battleship was sunk!!\n", player);
	}
	if (destroyer == 0)
	{
		printf("Player %d's Destroyer was sunk!!\n", player);
		fprintf(infile, "Player %d's Destroyer was sunk!!\n", player);
	}
	if (submarine == 0)
	{
		printf("Player %d's Submarine was sunk!!\n", player);
		fprintf(infile, "Player %d's Submarine was sunk!!\n", player);
	}
}