#include "PA4.h"
// displays the Opening menu
int menu(void)
{
	int option = 0;

	do
	{
		printf("1. Print game rules\n");
		printf("2. Play game\n");
		printf("3. Exit game\n");
		scanf("%d", &option);
		system("cls"); // clear the console window
	} while ((option < 1) || (option > 3)); // input validation loop

	return option;
}

//takes the option from the user and does the coresponding action
void run_app(int option)
{
	

	switch (option) // possible values? 1 - 3
	{
	case RULES: // print_game_rules ()
		print_game_rules();
		break;
	case PLAY: // play_craps ()
		play_game();
		break;
	case EXIT: // exit ()
		printf("Quitting\n");
		break;
	default: // catch all would execute if the other cases are not matched
		break;
	}
}

void play_game(void)
{
	int die1 = 0, die2 = 0, sum = 0, point = 0, rolls = 0, point_val = 0;
	double wager = 0, balance = 0, current_balance = 0;

	balance = get_bank_balance();
	wager = get_wager_amount();
	check_wager_amount(wager, balance);

	die1 = roll_die();
	die2 = roll_die();
	sum = calculate_sum_dice(die1, die2);
	point_val = calculate_sum_dice(die1, die2);
	do {	
		if (rolls == 0)
		{
			sum = calculate_sum_dice(die1, die2);
			point = is_win_loss_or_point(sum);
			++rolls;
		}
		else
		{
			printf("Your point: %d\n", point_val);
			die1 = roll_die();
			die2 = roll_die();
			sum = calculate_sum_dice(die1, die2);
			point = is_point_loss_or_neither(sum, point_val);	
			++rolls;
		}
		current_balance = adjust_bank_balance(balance, wager, point);

		printf("First die: %d\n", die1);
		printf("Second die: %d\n", die2);
		printf("Sum of the die: %d\n", sum);
		chatter_messages(rolls, point, balance, current_balance);

		system("pause");
		system("cls");
	} while ((point != 1) && (point != 0));

	run_app(menu());
	
}

//roles the die using random numbers
int roll_die(void)
{
	// generate a number 1 - 6
	int die_value = 0;

	die_value = rand() % 6 + 1;

	return die_value;
}

// prints the game rules
void print_game_rules(void)
{
	printf("A player rolls two dice. Each die has six faces. These faces contain 1, 2, 3, 4, 5, and 6 spots. After the dice have come to rest,");
	printf("the sum of the spots on the two upward faces is calculated. If the sum is 7 or 11 on the first throw, the player wins. If the sum ");
	printf("is 2, 3, or 12 on the first throw (called \"craps\"), the player loses (i.e. the \"house\" wins). If the sum is 4, 5, 6, 8, 9, or 10 on the ");
	printf("first throw, then the sum becomes the player's \"point.\" To win, you must continue rolling the dice until you \"make your point.\" ");
	printf("The player loses by rolling a 7 before making the point.\n");
}

//prompts user for initial bank balance
double get_bank_balance(void)
{
	double balance = 0;

	printf("Enter your initial bank balance: ");
	scanf("%lf", &balance);

	return balance;
}

//prompts user for a wager amount
double get_wager_amount(void)
{
	double wager = 0;

	printf("Enter your wager for the roll: ");
	scanf("%lf", &wager);

	return wager;
}

//checks if the wager is within the user's balance
int check_wager_amount(double wager, double balance)
{
	int valid = 0;

	if (wager < balance)
	{
		valid = 1;
	}
	else
	{
		return valid;
	}
}

//sums up the value of both of the rolls
int calculate_sum_dice(int die1_value, int die2_value)
{
	int sum = 0;

	sum = die1_value + die2_value;

	return sum;
}

//determines if the user wins, loses, or makes a point on the first roll
int is_win_loss_or_point(int sum_dice)
{
	int point = 0;

	if (sum_dice == 7 || sum_dice == 11)
	{
		point = 1;
	}
	else if ((sum_dice >= 4 && sum_dice <= 6) ||
			(sum_dice >= 8 && sum_dice <= 10))
	{
		point = -1;
	}

	return point;
}

//determines if the user wins, loses, or plays again after the first roll
int is_point_loss_or_neither(int sum_dice, int point_value)
{
	int craps = -1;

	if (sum_dice == point_value)
	{
		craps = 1;
	}
	else if (sum_dice == 7)
	{
		craps = 0;
	}

	return craps;
}

//determines whether or not the wager amount is subtracted from the balance
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract)
{
	double new_balance = bank_balance;

	if (add_or_subtract == 1)
	{
		new_balance = bank_balance + wager_amount;
	}
	else if (add_or_subtract == 0)
	{
		new_balance = bank_balance - wager_amount;
	}

	return new_balance;
}

void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance)
{
	printf("Number of rolls: %d\n", number_rolls);
	printf("Intial bank balance: %.2lf\n", initial_bank_balance);
	printf("Current balance: %.2lf\n", current_bank_balance);
	if (win_loss_neither == 1)
	{
		printf("Congratulations!! You won!!");
	}
	else if (win_loss_neither == 0)
	{
		printf("Sorry....you lose :(");
	}
	else
	{
		printf("Roll again\n");
		system("pause");
	}
}