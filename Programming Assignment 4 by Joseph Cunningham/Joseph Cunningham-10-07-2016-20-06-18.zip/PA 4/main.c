/*	Name: Joseph Cunningham
Date: 10/7/16
Description: this program simulates the game craps
*/

#include "PA4.h"

int main(void)
{
	int option = 0, die1 = 0, die2 = 0;

	srand((unsigned int)time(NULL)); // seed the random number generator

	option = menu();

	run_app(option);
	

	system("pause"); // will display "Press any key to continue..."
	system("cls");


	return 0;
}