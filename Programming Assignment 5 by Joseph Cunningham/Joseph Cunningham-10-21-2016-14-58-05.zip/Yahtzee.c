#include "Yahtzee.h"

int menu(void)
{
	int option = 0;

	do
	{
		printf("1. Print game rules\n");
		printf("2. Play game\n");
		printf("3. Exit game\n");
		scanf("%d", &option);
		system("cls"); 
	} while ((option < 1) || (option > 3)); 

	run_app(option);

	return option;
}

void run_app(int option)
{
	int p1_scorecard[14] = { 0 }, p2_scorecard[14] = { 0 }, p1_score_selection[14] = { 0 }, p2_score_selection[14] = { 0 }, rounds = 1;

	switch (option) 
	{
	case RULES: 
		print_game_rules();
		break;
	case PLAY: 
		while (rounds < 14)
		{
			play_game(p1_scorecard, 1, p1_score_selection);
			play_game(p2_scorecard, 2, p2_score_selection);
			++rounds;
		}
		break;
	case EXIT: 
		printf("Thanks for playing! Now exiting....\n");
		break;
	default: 
		break;
	}
}

void print_game_rules(void)
{
	printf("Basically just be a better die roller than your oppenent\n");
	system("pause");
	system("cls");
	menu();
}

void play_game(int scorecard[], int player, int score_selection[])
{
	int die[5] = { 0 }, die_values[7] = { 0 }, die_held[5] = { 0 };
	int rolls = 0, total_score = 0;
	char combo = '\0';
	do
	{
		reset(die_values, 7);

		printf("PLayer %d Roll the die\n", player);
		system("pause");
		system("cls");
		printf("[PLAYER %d]\n\n", player);
		roll_dice(die, 5);					//rolls die
		++rolls;							//updates rolls
		for (int index = 0; index < 5; index++)
		{
			if (die_held[index] != 0)
			{
				die[index] = die_held[index];
			}
		}
		print_dice(die, 5);					//displays die
		count_dice(die, 5, die_values);		//counts values of die
		print_dice(die_values, 6);			//displays # of values
		if (rolls < 3)
		{
			reset(die_held, 5);
			hold_die(die_held, die);
			printf("Do you want to use this roll for a combination? (Y/N)\n");
			scanf(" %c", &combo);
		}
		system("cls");
	} while ((combo != 'y' && combo != 'Y') && rolls < 3);
	
	combinations(scorecard, die, die_values, player, score_selection);
	total_score = sum_all_die(scorecard, 14);
	printf("Total score: %d\n", total_score);
	printf("Next players turn....\n");
	system("pause");
	system("cls");
	}

void roll_dice(int dice[], int size)
{
	int index = 0;

	for (index = 0; index < size; ++index)
	{
		dice[index] = rand() % 6 + 1;
	}
}

void count_dice(int dice[], int size, int dice_value_count[])
{
	int index = 0, new_index = 0;

	while (index < size)
	{
		new_index = dice[index++];
		dice_value_count[new_index] += 1;
	}
}

void print_dice(int num[], int size)
{
	int index = 0;
	if (size > 5)
	{
		for (index = 0; index < size; ++index)
		{
			printf("Number of %d's: %d\n", index + 1, num[index + 1]);
		}
	}
	else
	{
		for (index = 0; index < size; ++index)
		{
			printf("Die %d: %d\n", index + 1, num[index]);
		}
	}
}

void hold_die(int die_held[], int die[])
{

	int num_die_held = 0, num_hold = 0, is_hold = 0;
	char hold_die = '\0';

	printf("Do you want to hold any die? (Y/N)\n");
	scanf(" %c", &hold_die);
	if (hold_die == 'Y' || hold_die == 'y')
	{
		printf("How many die do you want to hold?\n");
		scanf("%d", &num_die_held);
		for (int count = 1; count <= num_die_held; count++)
		{
			printf("Select your #%d die to hold: ", count);
			scanf("%d", &num_hold);
			if (num_hold >= 1 && num_hold <= 5) //checks to see if number entered is within number of die
			{
				die_held[num_hold - 1] = die[num_hold - 1];
			}
		}
		printf("Die held.....\n");
		print_dice(die_held, 5);
	}
}

int combo_menu(void)
{
	int option = 0;
	do {
		printf("Which combination do you want to use: \n");
		printf("\n");
		printf(" 1. Sum of 1's        7. Three-of-a-kind\n");
		printf(" 2. Sum of 2's        8. Four-of-a-kind\n");
		printf(" 3. Sum of 3's        9. Full house\n");
		printf(" 4. Sum of 4's        10. Small straight\n");
		printf(" 5. Sum of 5's        11. Large straight\n");
		printf(" 6. Sum of 6's        12. Yahtzee\n");
		printf("            13. Chance\n");
		scanf("%d", &option);
		system("cls");
	} while (option < 1 && option > 13);

	return option;
}

void combinations(int scorecard[], int dice[], int dice_value_count[], int player, int score_selection[])
{
	int option = 0, a_kind = 0, full_house = 0, small = 0, large = 0, yahtzee = 0, chance = 0;
	printf("[PLAYER %d]\n\n", player);
	print_dice(dice, 5);
	print_dice(dice_value_count, 6);
	option = combo_menu();
	if (score_selection[option] == 1)
	{
		printf("Sorry, you already used that combination, select again\n");
		combinations(scorecard, dice, dice_value_count, player, score_selection);
	}
	else
	{
		switch (option)
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
			scorecard[option] = sums(option, dice_value_count[option]);
			break;
		case 7:
			a_kind = of_a_kind(dice_value_count, 7, 3);
			invalid_selection(a_kind, scorecard, dice, dice_value_count, player, score_selection, option);
			printf("Score + %d\n", sum_all_die(dice, 5));
		case 8:
			if (option == 8)
			{
				a_kind = of_a_kind(dice_value_count, 7, 4);
				invalid_selection(a_kind, scorecard, dice, dice_value_count, player, score_selection, option);
				printf("Score + %d\n", sum_all_die(dice, 5));
			}
			scorecard[option] = sum_all_die(dice, 5);
			break;
		case 9:
			full_house = is_full_house(dice_value_count, 7);
			invalid_selection(full_house, scorecard, dice, dice_value_count, player, score_selection, option);
			printf("Score + 25\n");
			scorecard[option] = 25;
			break;
		case 10:
			small = is_small_straight(dice_value_count, 7);
			invalid_selection(small, scorecard, dice, dice_value_count, player, score_selection, option);
			printf("Score + 30\n");
			scorecard[option] = 30;
			break;
		case 11:
			large = is_large_straight(dice_value_count, 7);
			invalid_selection(large, scorecard, dice, dice_value_count, player, score_selection, option);
			printf("Score + 40\n");
			scorecard[option] = 40;
			break;
		case 12:
			yahtzee = is_yahtzee(dice_value_count, 7);
			invalid_selection(yahtzee, scorecard, dice, dice_value_count, player, score_selection, option);
			printf("YAHTZEE!!!!!!\n Score + 50\n");
			scorecard[option] = 50;
			break;
		case 13:
			chance = sum_all_die(dice, 5);
			printf("Score + %d\n", chance);
			scorecard[option] = chance;
			break;
		default:
			break;
		}
	}
	
}

int sums(int dice_value, int num_of_value)
{
	int sum = 0;

	sum = dice_value * num_of_value;
	printf("Score + %d\n", sum);
	return sum;
}

void reset(int any_array[], int size)
{

	for (int index = 0; index < size; index++)
	{
		any_array[index] = 0;
	}
}

int sum_all_die(int die[], int size)
{
	int sum = 0;
	
	for (int index = 0; index < size; index++)
	{
		sum += die[index];
	}
	return sum;
}

int of_a_kind(int dice_value_count[], int size, int kind)
{
	int a_kind = 0;

	for (int index = 0; index < size; index++)
	{
		if (dice_value_count[index] == kind)
		{
			a_kind = 1;
		}
	}
	return a_kind;
}

int is_full_house(int dice_value_count[], int size)
{
	int full_house = 0;

	for (int index = 0; index < size; index++)
	{
		if (dice_value_count[index] == 3) // checks for a 3 of a kind
		{
			for (int index2 = 0; index2 < size; index2++)
			{
				if (dice_value_count[index2] == 2) // checks for a 2 of a kind
				{
					full_house = 1;
				}
			}
		}
	}
	return full_house;
}

int is_small_straight(int dice_value_count[], int size)
{
	int small_straight = 0, zeros = 0, twos = 0, threes_and_up = 0;

	for (int index = 1; index < size; index++)
	{
		if (dice_value_count[index] > 2)
		{
			threes_and_up += 1;
		}
		else if (dice_value_count[index] == 2)
		{
			twos += 1;
		}
		else if (dice_value_count[index] == 0);
		{
			zeros += 1;
		}	
	}
	if (threes_and_up == 0)
	{
		if (zeros < 3)
		{
			if (twos < 2)
			{
				small_straight = 1;
			}
		}
	}
	return small_straight;
}

int is_large_straight(int dice_value_count[], int size)
{
	int large_straight = 0, zeros = 0, twos_and_up = 0;

	for (int index = 1; index < size; index++)
	{
		if (dice_value_count[index] > 1)
		{
			twos_and_up += 1;
		}
		else if (dice_value_count[index] == 0);
		{
			zeros += 1;
		}
	}
	if (twos_and_up == 0)
	{
		if (zeros < 2)
		{
			large_straight = 1;
		}
	}
	return large_straight;
}

void invalid_selection(int yes_no, int scorecard[], int dice[], int dice_value_count[], int player, int score_selection[], int option)
{
	if (yes_no != 1)
	{
		printf("Selection invalid, select again\n");
		combinations(scorecard, dice, dice_value_count, player, score_selection);
	}
	else
	{
		score_selection[option] += 1;
	}
}

int is_yahtzee(int dice_value_count[], int size)
{
	int yahtzee = 0;

	for (int index = 0; index < size; index++)
	{
		if (dice_value_count[index] == 5)
		{
			yahtzee = 1;
		}
	}
	return yahtzee;
}