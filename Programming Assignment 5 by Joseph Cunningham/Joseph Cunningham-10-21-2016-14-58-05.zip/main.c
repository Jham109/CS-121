/*	Name: Joseph Cunningham
Date: 9/14/16
Description: Develop and implement an interactive two-player Yahtzee game.
*/


#include "Yahtzee.h"

int main(void)
{	
	srand((unsigned int)time(NULL));

	menu();
}

