#include "Read.h"

void run_app(ascii, character)
{

	determine_ascii_value(character);
	print_int(ascii, determine_ascii_value(character));
}

//Opens "input.dat" for reading.
FILE *open_input_file(void)
{
	FILE *infile = NULL;
	infile = fopen("input.dat", "r");
	return infile;
}

// Reads one character from the input file.
char read_character(FILE *input) 
{
	char one_character = "\0";
	fscanf(input, "%c", &one_character);
	return one_character;
}

//  Returns the ASCII value of the character passed into the function.
int determine_ascii_value(char character)
{
	int ascii = 0;
	ascii = character;
	return ascii;
}

// Determines if the character is a newline, 
// if the character is a newline a 1 is returned otherwise a 0 is returned. 
int is_line(char character)
{
	int newline = NOT_NEWLINE;

	if (character == '\n')
	{
		newline = NEWLINE;
	}

	return newline;
}

// Determines if the character passed into the function indicates the end of a line
int number_lines(char character, int current_number_lines)
{
	int lines = current_number_lines;

	if (is_line(character))
	{
		lines += current_number_lines + 1;
	}

	return lines;
}

// Determines if the character is a vowel
int is_vowel(char character)
{
	int vowel = NOT_VOWEL;

	if ((character == 'A') || (character == 'a') ||
		(character == 'E') || (character == 'e') ||
		(character == 'I') || (character == 'i') ||
		(character == 'O') || (character == 'o') ||
		(character == 'U') || (character == 'u'))
	{
		vowel = VOWEL;
	}

	return vowel;
}

// Determines if the character passed into the function is a vowel
int number_vowels(char character, int current_number_vowels)
{
	int vowels = current_number_vowels;

	if (is_vowel(character))
	{
		vowels += current_number_vowels + 1;
	}

	return vowels;
}

// Determines if the character is a digit(i.e. '0' - '9'), if the character is a digit a 3 is returned otherwise a 0 is returned.
int is_digit(char character)
{
	int digit = 0;
	if ((character >= '0') && (character <= '9'))
	{
		digit = 3;
	}

	return digit;
}

// Determines if the character passed into the function is a digit 
int number_digits(char character, int current_number_digits)
{
	int digits = NOT_DIGIT;

	if (is_digit(character) == DIGIT)
	{
		digits += current_number_digits + 1;
	}

	return digits;
}

// Determines if the character is an alpha character (i.e. 'a' - 'z', 'A' - 'Z'), if the character is an alpha character a 4 is returned otherwise a 0 is returned.
int is_alpha(char character)
{
	int alpha = 0;

	if (((character >= 'a') && (character <= 'z')) ||
		((character >= 'A') && (character <= 'Z')))
	{
		alpha = 4;
	}

	return alpha;
}

// Determines if the character passed into the function is an alpha character
int number_alphas(char character, int current_number_alphas)
{
	int alphas = NOT_ALPHA;

	if (is_alpha(character) == ALPHA)
	{
		alphas += current_number_alphas + 1;
	}

	return alphas;
}

// Determines if the character is a lowercase character, if the character is a lowercase character a 5 is returned otherwise a 0 is returned.
int is_lower(char character)
{
	int lower = 0;

	if ((character >= 'a') && (character <= 'z'))
	{
		lower = 5;
	}

	return lower;
}

// Determines if the character passed into the function is a lowercase character
int number_lowers(char character, int current_number_lowers)
{
	int lowers = NOT_LOWER;

	if (is_lower(character) == LOWER)
	{
		lowers += current_number_lowers + 1;
	}

	return lowers;
}

// Determines if the character is an uppercase character, if the character is an uppercase character a 6 is returned otherwise a 0 is returned.
int is_upper(char character)
{
	int upper = 0;

	if ((character >= 'A') && (character <= 'Z'))
	{
		upper = 6;
	}

	return upper;
}

// Determines if the character passed into the function is a uppercase character
int number_uppers(char character, int current_number_uppers)
{
	int uppers = NOT_UPPER;

	if (is_upper(character) == UPPER)
	{
		uppers += current_number_uppers + 1;
	}

	return uppers;
}

// Determines if the character is a whitespace character
int is_space(char character)
{ 
	int space = 0;

	if ((character == ' ') || (character == '\f') ||
		(character == '\n') || (character == '\r') ||
		(character == '\t') || (character == '\v'))
	{
		space = 7;
	}

	return space;
}

// Determines if the character passed into the function is a space character
int number_spaces(char character, int current_number_spaces)
{
	int whitespace = NOT_WHITESPACE;

	if (is_space(character) == WHITESPACE)
	{
		whitespace += current_number_spaces + 1;
	}

	return whitespace;
}

// Determines if the character is an alpha or digit character
int is_alnum(char character)
{
	int alnum = 0;

	if (((character >= 'a') && (character <= 'z')) ||
		((character >= 'A') && (character <= 'Z')) ||
		(character >= '0') && (character <= '9'))
	{
		alnum = 8;
	}

	return alnum;
}

// Determines if the character passed into the function is an alphanumeric character
int number_alnums(char character, int current_number_alnums)
{
	int alnums = NOT_ALNUM;

	if (is_alnum(character) == ALNUM)
	{
		alnums += current_number_alnums + 1;
	}

	return alnums;
}

// Determines if the character is a punctuation character
int is_punct(char character)
{
	int puncuation = 0;

	if((character >= '!') && (character <= '/') ||
		(character >= ':') && (character <= '?'))
	{
		puncuation = 9;
	}

	return puncuation;
}

// Determines if the character passed into the function is a punctuation character
int number_puncts(char character, int current_number_puncts)
{
	int puncts = NOT_PUNCT;

	if (is_punct(character) == PUNCT)
	{
		puncts += current_number_puncts + 1;
	}

	return puncts;
}

//  Prints an integer to an output file.
void print_int(FILE *outfile, int number) 
{
	fprintf(outfile, "%d\n", number);
}

void print_stats(FILE *outfile, char header[], int number)
{
	fprintf(outfile, "%s: %d\n", header, number);
}


