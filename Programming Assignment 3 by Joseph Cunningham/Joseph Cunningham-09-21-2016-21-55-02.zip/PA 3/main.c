/*	Name: Joseph Cunningham
Date: 9/14/16
Description: 
*/



#include "Read.h"

int main(void)
{
	int vowels = 0, lines = 1, digits = 0, alphas = 0, lowers = 0,
		uppers = 0, spaces = 0, alnums = 0, puncts = 0;
	char character = '\0', char2 = '\0', char3 = '\0', char4 = '\0', char5 = '\0',
		 char6 = '\0', char7 = '\0', char8 = '\0', char9 = '\0', char10 = '\0';
	FILE *infile = NULL, *outfile = NULL, *ascii = NULL;

	ascii = fopen("output_ascii.dat", "w");
	outfile = fopen("output_stats.dat", "w");
	infile = open_input_file();
	
	// passes each character through the functions 
	character = read_character(infile);
	lines += number_lines(character, 0);
	vowels += number_vowels(character, 0);
	digits += number_digits(character, 0);
	alphas +=number_alphas(character, 0);
	lowers += number_lowers(character, 0);
	uppers += number_uppers(character, 0);
	spaces += number_spaces(character, 0);
	alnums += number_alnums(character, 0);
	puncts += number_puncts(character, 0);

	char2 = read_character(infile);
	lines += number_lines(char2, 0);
	vowels += number_vowels(char2, 0);
	digits += number_digits(char2, 0);
	alphas += number_alphas(char2, 0);
	lowers += number_lowers(char2, 0);
	uppers += number_uppers(char2, 0);
	spaces += number_spaces(char2, 0);
	alnums += number_alnums(char2, 0);
	puncts += number_puncts(char2, 0);

	char3 = read_character(infile);
	lines += number_lines(char3, 0);
	vowels += number_vowels(char3, 0);
	digits += number_digits(char3, 0);
	alphas += number_alphas(char3, 0);
	lowers += number_lowers(char3, 0);
	uppers += number_uppers(char3, 0);
	spaces += number_spaces(char3, 0);
	alnums += number_alnums(char3, 0);
	puncts += number_puncts(char3, 0);

	char4 = read_character(infile);
	lines += number_lines(char4, 0);
	vowels += number_vowels(char4, 0);
	digits += number_digits(char4, 0);
	alphas += number_alphas(char4, 0);
	lowers += number_lowers(char4, 0);
	uppers += number_uppers(char4, 0);
	spaces += number_spaces(char4, 0);
	alnums += number_alnums(char4, 0);
	puncts += number_puncts(char4, 0);

	char5 = read_character(infile);
	lines += number_lines(char5, 0);
	vowels += number_vowels(char5, 0);
	digits += number_digits(char5, 0);
	alphas += number_alphas(char5, 0);
	lowers += number_lowers(char5, 0);
	uppers += number_uppers(char5, 0);
	spaces += number_spaces(char5, 0);
	alnums += number_alnums(char5, 0);
	puncts += number_puncts(char5, 0);

	char6 = read_character(infile);
	lines += number_lines(char6, 0);
	vowels += number_vowels(char6, 0);
	digits += number_digits(char6, 0);
	alphas += number_alphas(char6, 0);
	lowers += number_lowers(char6, 0);
	uppers += number_uppers(char6, 0);
	spaces += number_spaces(char6, 0);
	alnums += number_alnums(char6, 0);
	puncts += number_puncts(char6, 0);

	char7 = read_character(infile);
	lines += number_lines(char7, 0);
	vowels += number_vowels(char7, 0);
	digits += number_digits(char7, 0);
	alphas += number_alphas(char7, 0);
	lowers += number_lowers(char7, 0);
	uppers += number_uppers(char7, 0);
	spaces += number_spaces(char7, 0);
	alnums += number_alnums(char7, 0);
	puncts += number_puncts(char7, 0);

	char8 = read_character(infile);
	lines += number_lines(char8, 0);
	vowels += number_vowels(char8, 0);
	digits += number_digits(char8, 0);
	alphas += number_alphas(char8, 0);
	lowers += number_lowers(char8, 0);
	uppers += number_uppers(char8, 0);
	spaces += number_spaces(char8, 0);
	alnums += number_alnums(char8, 0);
	puncts += number_puncts(char8, 0);

	char9 = read_character(infile);
	lines += number_lines(char9, 0);
	vowels += number_vowels(char9, 0);
	digits += number_digits(char9, 0);
	alphas += number_alphas(char9, 0);
	lowers += number_lowers(char9, 0);
	uppers += number_uppers(char9, 0);
	spaces += number_spaces(char9, 0);
	alnums += number_alnums(char9, 0);
	puncts += number_puncts(char9, 0);

	char10 = read_character(infile);
	lines += number_lines(char10, 0);
	vowels += number_vowels(char10, 0);
	digits += number_digits(char10, 0);
	alphas += number_alphas(char10, 0);
	lowers += number_lowers(char10, 0);
	uppers += number_uppers(char10, 0);
	spaces += number_spaces(char10, 0);
	alnums += number_alnums(char10, 0);
	puncts += number_puncts(char10, 0);

	// prints the ascii values
	run_app(ascii, character);
	run_app(ascii, char2);
	run_app(ascii, char3);
	run_app(ascii, char4);
	run_app(ascii, char5);
	run_app(ascii, char6);
	run_app(ascii, char7);
	run_app(ascii, char8);
	run_app(ascii, char9);
	run_app(ascii, char10);

	// prints to output_stats
	print_stats(outfile, "Number Lines: ", lines);
	print_stats(outfile, "Number Vowels: ", vowels);
	print_stats(outfile, "Number Digits: ", digits);
	print_stats(outfile, "Number Alphas: ", alphas);
	print_stats(outfile, "Number Lowers: ", lowers);
	print_stats(outfile, "Number Uppers: ", uppers);
	print_stats(outfile, "Number Spaces: ", spaces);
	print_stats(outfile, "Number Alnums: ", alnums);
	print_stats(outfile, "Number Puncts: ", puncts);

	// closes the files
	fclose(infile);
	fclose(outfile);
	fclose(ascii);

	return 0;
}