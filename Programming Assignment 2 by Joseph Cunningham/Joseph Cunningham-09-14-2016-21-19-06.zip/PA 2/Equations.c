
#include "equations.h"

double calculate_newtons_2nd_law(double mass, double acceleration)
{
	double force = 0.0;
	force = mass * acceleration;
	return force;
}

double calculate_volume_cylinder(double radius, double height)
{
	double volume_cylinder = 0;
	double PI = 3.141592;
	volume_cylinder = PI * (radius * radius) * height;
	return volume_cylinder;
}

char perform_character_encoding(char plaintext_character, int shift)
{
	char encoded_character = '\0';
	encoded_character = (plaintext_character - 'A') + 'a' - shift;
	return encoded_character;
}

double calculate_parallel_resistance(int r1, int r2, int r3)
{
	double parrallel_resistance = 0.0;
	parrallel_resistance = 1 / (1 / (double)r1 + 1 / (double)r2 + 1 / (double)r3);
	return parrallel_resistance;
}

double calculate_resistive_divider(int r1, int r2, double vin)
{
	double vout = 0.0;
	vout = r2 / ((r1 + r2) * vin);
	return vout;
}

double calculate_distance_between_2pts(double x1, double y1, double x2, double y2)
{
	double distance = 0.0;
	distance = sqrt((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2));
	return distance;
}

double calculate_general_equation(int a, double x, double z)
{
	double y = 0.0;
	y = -x * (3 / 4) - (z + a / (a % 2));
	return y;
}