/*	Name: Joseph Cunningham
	Date: 9/14/16
	Description: This program the user and evaluates equation baased on the input
			from the user. Also it is organized in different functions to 
			evaluate each equation and return it.
*/


#include "equations.h"
int main(void)
{
	double mass = 0, acceleration = 0, force = 0,
		height = 0, radius = 0, volume_cylinder = 0,
		parrallel_resistance = 0,
		vout = 0, vin = 0,
		x1 = 0, x2 = 0, y1 = 0, y2 = 0, distance = 0,
		z= 0, x = 0, y = 0;
	char plaintext_character = '\0', encoded_character = '\0';
	int shift = 0, R1 = 0, R2 = 0, R3 = 0, a = 0;

	// Prompts the user for numbers to use in the equations then calls the corresponding function
	// and displays the result

	// 1.Newton's second law of motion
	printf("Enter the mass and acceleration (both floating-point values) to calculate the force in Newton's 2nd law: ");
	scanf("%lf%lf", &mass, &acceleration);
	force = calculate_newtons_2nd_law(mass, acceleration);
	printf("Force = %.2lf\n\n", force);

	// 2.Volume of a cylinder
	printf("Enter the radius and height (both floating-point values) to calculate the volume of a cylinder: ");
	scanf("%lf%lf", &radius, &height);
	volume_cylinder = calculate_volume_cylinder(radius, height);
	printf("Volume of the cylinder = %.2lf\n\n", volume_cylinder);

	// 3.Character encoding
	printf("Enter a character and an integer shift value: ");
	scanf(" %c%d", &plaintext_character, &shift);
	encoded_character = perform_character_encoding(plaintext_character, shift);
	printf("New Character = %c\n\n", encoded_character);

	// 4.Equivalent parallel resistance
	printf("Enter three resistors (all integers) for use in the equivalent parallel resistance formula: ");
	scanf("%d%d%d", &R1, &R2, &R3);
	parrallel_resistance = calculate_parallel_resistance(R1, R2, R3);
	printf("Parrallel resistance = %.2lf\n\n", parrallel_resistance);

	// 5.Resistive divider
	printf("Enter two integers (R1 and R2) and a voltage input for use in the resistive divider formula: ");
	scanf("%d%d%lf", &R1, &R2, &vin);
	vout = calculate_resistive_divider(R1, R2, vin);
	printf("Voltage output = %.2lf\n\n", vout);

	// 6.Distance Formula
	printf("Enter the two points (x1 y1 x2 y2) for use in the distance formula (all coordinates are floating point values): ");
	scanf("%lf%lf%lf%lf", &x1, &y1, &x2, &y2);
	distance = calculate_distance_between_2pts(x1, y1, x2, y2);
	printf("Distance = %.2lf\n\n", distance);

	// 7 General Equation
	printf("Enter two floating point values and one integer: ");
	scanf("%lf%lf%d", &x, &z, &a);
	y = calculate_general_equation(a, x, z);
	printf("y = %.2lf\n\n", y);
}

